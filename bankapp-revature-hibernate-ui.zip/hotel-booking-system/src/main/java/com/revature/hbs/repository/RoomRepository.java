package com.revature.hbs.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.revature.hbs.model.Room;


@Repository
public interface RoomRepository extends CrudRepository<Room, Integer> {

}
