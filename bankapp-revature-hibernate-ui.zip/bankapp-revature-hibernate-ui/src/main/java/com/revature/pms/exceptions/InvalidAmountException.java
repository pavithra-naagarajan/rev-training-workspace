package com.revature.pms.exceptions;

public class InvalidAmountException extends Exception {
	public InvalidAmountException() {

	}

	public InvalidAmountException(String message) {
		super(message);
	}

}
