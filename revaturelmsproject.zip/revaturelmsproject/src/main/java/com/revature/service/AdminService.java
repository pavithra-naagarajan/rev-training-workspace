package com.revature.service;

import java.util.List;

import com.revature.model.Admin;
import com.revature.model.User;

public interface AdminService {
	
	

	public Admin getAdminById(Long adminId);

	public List<Admin> getAdminByName(String adminName);
	
	public List<Admin> getAdminByRole(String role);
	
	public boolean isAdminExists(Long adminId);

	public List<Admin> getAllAdmins();

}
