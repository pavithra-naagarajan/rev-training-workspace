package com.revature.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.revature.dao.AdminDAO;
import com.revature.dao.impl.AdminDAOImpl;
import com.revature.model.Admin;
import com.revature.model.User;
import com.revature.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService  {

	
	
	@Autowired
	private AdminDAO adminDAO;
	
	@Override
	public Admin getAdminById(Long adminId) {
		return adminDAO.getAdminById(adminId);
		
	}

	@Override
	public List<Admin> getAdminByName(String adminName) {
		return (List<Admin>) adminDAO.getAdminByName(adminName);
		
	}

	@Override
	public List<Admin> getAdminByRole(String role) {
		return (List<Admin>) adminDAO.getAdminByRole(role);
	}

	@Override
	public boolean isAdminExists(Long adminId) {
		Admin adminData = adminDAO.getAdminById(adminId);
		return (adminData!=null)? true:false;
	}

	@Override
	public List<Admin> getAllAdmins() {
		return (List<Admin>) adminDAO.getAllAdmins();
	}

}
