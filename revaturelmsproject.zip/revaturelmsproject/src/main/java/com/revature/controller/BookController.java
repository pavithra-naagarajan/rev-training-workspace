package com.revature.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.revature.model.Book;
import com.revature.model.User;
import com.revature.service.AdminService;
import com.revature.service.BookService;
import com.revature.service.impl.BookServiceImpl;

@CrossOrigin(origins = "http://localhost:4200")

@RestController
@RequestMapping("book")
public class BookController {
	
	@Autowired
	BookService bookService;
	
	
	
	static ResponseEntity<String> response;
	static  ResponseEntity<Book> responseEntity;
	
	
	// get book by id
		@GetMapping("{bookId}")
		public ResponseEntity<Book> getBookById(@PathVariable("bookId") Long bookId) {
			
			Book book=new Book();
			if (bookService.isBookExists(bookId)) {
				book = bookService.getBookById(bookId);
				responseEntity = new ResponseEntity<Book>(book, HttpStatus.OK);
			} else
				responseEntity = new ResponseEntity<Book>(book, HttpStatus.NO_CONTENT);

			return responseEntity;

		}

		// insert a book
		@PostMapping
		public ResponseEntity<String> addBook(@RequestBody Book book) {
			
			long bookId = book.getBookId();

			if (bookService.isBookExists(bookId))

				response = new ResponseEntity<String>(HttpStatus.CONFLICT);

			else {
				bookService.addBook(book);

				response = new ResponseEntity<String>(HttpStatus.OK);
			}

			return response;
		}
		
		//update a book
		@PutMapping
		public ResponseEntity<String> updateBook(@RequestBody Book book) {
			
			long bookId=book.getBookId();
			
			if(bookService.isBookExists(bookId)) {
				bookService.updateBook(book);
		
			response =new ResponseEntity<String>(HttpStatus.OK);
			}
			else 
				response =new ResponseEntity<String>(HttpStatus.NO_CONTENT);
			
			
			
			return response;
		}

		//delete a book
		@DeleteMapping("/{bookId}")
		public ResponseEntity<String> deleteBook(@PathVariable("bookId") Long bookId) {
			
			if (bookService.isBookExists(bookId)) {
				bookService.deleteBook(bookId);
				
				response = new ResponseEntity<String>(HttpStatus.OK);
			} else
				response = new ResponseEntity<String>(HttpStatus.NO_CONTENT);
			

			return response;
		}
		
		@GetMapping("/bookName/{bookName}")  
		 public ResponseEntity <List<Book>> getBookByName(@PathVariable String  bookName){  
			 
			 return new ResponseEntity<>(bookService.getBookByName(bookName), HttpStatus.OK); 
		}
		@GetMapping("/author/{authorName}")  
		 public ResponseEntity <List<Book>> getBookByAuthor(@PathVariable String  authorName){  
			 
			 return new ResponseEntity<>(bookService.getBookByAuthor(authorName), HttpStatus.OK); 
		}
		@GetMapping("/genre/{genre}")  
		 public ResponseEntity <List<Book>> getBookByGenre(@PathVariable String  genre){  
			 
			 return new ResponseEntity<>(bookService.getBookByGenre(genre), HttpStatus.OK); 
		}
		
		@GetMapping
		public ResponseEntity<List<Book>> getAllBooks() {
			 
			 return new ResponseEntity<>(bookService.getAllBooks(), HttpStatus.OK); 
		}
		
	
	

}
