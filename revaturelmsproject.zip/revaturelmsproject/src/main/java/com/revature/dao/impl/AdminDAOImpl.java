package com.revature.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.revature.dao.AdminDAO;
import com.revature.model.Admin;


@Repository
public class AdminDAOImpl implements AdminDAO {

	@Override
	public Admin getAdminById(Long adminId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Admin> getAdminByName(String adminName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Admin> getAdminByRole(String role) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isAdminExists(Long adminId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Admin> getAllAdmins() {
		// TODO Auto-generated method stub
		return null;
	}

}
