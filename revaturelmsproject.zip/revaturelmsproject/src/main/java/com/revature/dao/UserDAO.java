
package com.revature.dao;

import java.util.List;


import com.revature.model.User;

public interface UserDAO {

	public String addUser(User user);

	public String updateUser(User user);

	public String deleteUserById(Long userId);

	public User getUserById(Long userId);

	public User getUserByFirstAndLastName(String firstName, String lastName);

	public User getUserByMobileNumber(String mobileNumber);

	public User getUserByMailId(String mailId);

	public List<User> getUserByRole(String role);

	public boolean isUserExists(Long userId);

	public List<User> getAllUsers();

}
