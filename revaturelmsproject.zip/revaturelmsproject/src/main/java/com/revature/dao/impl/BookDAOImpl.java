package com.revature.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.revature.dao.BookDAO;
import com.revature.model.Book;



@Repository
public class BookDAOImpl implements BookDAO {

	@Override
	public String addBook(Book book) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateBook(Book book) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteBook(Long bookId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book getBookById(Long bookId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isBookExists(Long bookId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Book> getBookByName(String bookName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> getBookByAuthor(String authorName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> getBookByGenre(String genre) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return null;
	}

}
