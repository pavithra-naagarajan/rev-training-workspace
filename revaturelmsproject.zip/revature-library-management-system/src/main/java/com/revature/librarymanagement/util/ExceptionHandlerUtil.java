package com.revature.librarymanagement.util;

import org.springframework.http.HttpStatus;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import java.util.stream.Collectors;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.revature.librarymanagement.exception.DatabaseException;
import com.revature.librarymanagement.exception.DuplicateIdException;
import com.revature.librarymanagement.exception.IdNotFoundException;

import com.revature.librarymanagement.exception.NullValueException;
import com.revature.librarymanagement.response.HttpResponseStatus;
import static com.revature.librarymanagement.util.LibraryManagementConstants.*;

import java.util.List;

@ControllerAdvice
public class ExceptionHandlerUtil {

	private static final Logger logger = LogManager.getLogger(ExceptionHandlerUtil.class);

	/**
	 * This function handles Exception for DuplicateIdException.
	 * 
	 * @param e the object for DuplicateIdException class.
	 * @return ResponseEntity of HttpReponseStatus.
	 */
	@ExceptionHandler(DuplicateIdException.class)

	public ResponseEntity<HttpResponseStatus> duplicateIdFound(DuplicateIdException e) {
		logger.error(e.getMessage());

		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.CONFLICT.value(), e.getMessage()),
				HttpStatus.CONFLICT);
	}

	/**
	 * This function handles Exception for IdNotFoundException.
	 * 
	 * @param e the object for IdNotFoundException class.
	 * @return ResponseEntity of HttpReponseStatus.
	 */
	@ExceptionHandler(IdNotFoundException.class)

	public ResponseEntity<HttpResponseStatus> idNotFound(IdNotFoundException e) {
		logger.error(e.getMessage());

		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.NO_CONTENT.value(), e.getMessage()),
				HttpStatus.NOT_FOUND);
	}

	/**
	 * This function handles Exception for DatabaseException.
	 * 
	 * @param e the object for DatabaseException class.
	 * @return ResponseEntity of HttpReponseStatus.
	 */
	@ExceptionHandler(DatabaseException.class)

	public ResponseEntity<HttpResponseStatus> databaseException(DatabaseException e) {
		logger.error(e.getMessage());

		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.BAD_REQUEST.value(), e.getMessage()),
				HttpStatus.BAD_REQUEST);
	}

	/**
	 * This function handles Exception for NullValueException.
	 * 
	 * @param e the object for NullValueException class.
	 * @return ResponseEntity of HttpReponseStatus.
	 */
	@ExceptionHandler(NullValueException.class)

	public ResponseEntity<HttpResponseStatus> nullValueException(NullValueException e) {
		logger.error(e.getMessage());

		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.NO_CONTENT.value(), e.getMessage()),
				HttpStatus.NOT_FOUND);
	}

	/**
	 * This function handles Exception for HttpMessageNotReadableException.
	 * 
	 * @param e the object for HttpMessageNotReadableException class.
	 * @return ResponseEntity of HttpReponseStatus.
	 */
	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<HttpResponseStatus> httpMessage(HttpMessageNotReadableException e) {
		logger.error(e.getMessage());

		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY.value(), TYPE_MISMATCH),
				HttpStatus.UNPROCESSABLE_ENTITY);
	}

	/**
	 * This function handles Exception for MethodArgumentTypeMismatchException.
	 * 
	 * @param e the object for MethodArgumentTypeMismatchException class.
	 * @return ResponseEntity of HttpReponseStatus.
	 */
	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<HttpResponseStatus> invalidInputArgumentsFound(MethodArgumentTypeMismatchException e) {
		logger.error(e.getMessage());

		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.BAD_REQUEST.value(), INPUT_MISMATCH),
				HttpStatus.BAD_REQUEST);
	}

	/**
	 * This function handles Exception for MethodArgumentNotValidException.
	 * 
	 * @param e the object for MethodArgumentNotValidException class.
	 * @return ResponseEntity of HttpReponseStatus.
	 */
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<HttpResponseStatus> validationFailed(MethodArgumentNotValidException e) {
		logger.error(e.getMessage());

		List<String> details = e.getBindingResult().getFieldErrors().stream()
				.map(DefaultMessageSourceResolvable::getDefaultMessage).collect(Collectors.toList());

		return new ResponseEntity<>(
				new HttpResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY.value(), INPUT_MISMATCH, details),
				HttpStatus.UNPROCESSABLE_ENTITY);

	}

	/**
	 * This function handles Exception for internalServerErrorFound.
	 * 
	 * @param e the object for Exception class.
	 * @return ResponseEntity of HttpReponseStatus.
	 */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<HttpResponseStatus> internalServerErrorFound(Exception e) {
		logger.error(e.getMessage());
		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getMessage()),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
