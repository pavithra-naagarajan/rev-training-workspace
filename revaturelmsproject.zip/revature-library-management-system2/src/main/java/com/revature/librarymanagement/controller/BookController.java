package com.revature.librarymanagement.controller;
import static com.revature.librarymanagement.util.LibraryManagementConstants.*;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.revature.librarymanagement.dto.BookDto;

import com.revature.librarymanagement.response.HttpResponseStatus;
import com.revature.librarymanagement.service.BookService;

@CrossOrigin(origins = "*")

@RestController
@RequestMapping("book")
public class BookController {

	private static final Logger logger = LogManager.getLogger(BookController.class);

	@Autowired
	BookService bookService;

	
	@GetMapping("{bookId}")
	public ResponseEntity<HttpResponseStatus> getBookById(@PathVariable("bookId") Long bookId) {
		logger.info("Entering Get Book By Id Function");
		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.OK.value(),GET_OPERATION,bookService.getBookById(bookId)),HttpStatus.OK);


	}

	
	@PostMapping
	public ResponseEntity<HttpResponseStatus> addBook(@RequestBody BookDto bookDto) {
		logger.info("Entering Add Book Function");
		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.CREATED.value(),bookService.addBook(bookDto)),HttpStatus.CREATED);


	}


	@PutMapping
	public ResponseEntity<HttpResponseStatus> updateBook(@RequestBody BookDto bookDto) {

		logger.info("Entering Update Book Function");
		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.OK.value(),bookService.updateBook(bookDto)),HttpStatus.OK);


	}

	
	@DeleteMapping("/{bookId}")
	public ResponseEntity<HttpResponseStatus> deleteBook(@PathVariable("bookId") Long bookId) {
		logger.info("Entering Delete Book Function");
		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.OK.value(),bookService.deleteBook(bookId)),HttpStatus.OK);


	}
 
	@GetMapping("/bookname/{bookName}")
	public ResponseEntity<HttpResponseStatus> getBookByName(@PathVariable String bookName) {
		logger.info("Entering Get Book By Name Function");
		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.OK.value(),GET_OPERATION,bookService.getBookByName(bookName)),HttpStatus.OK);

	}

	
	@GetMapping("/author/{authorName}")
	public ResponseEntity<HttpResponseStatus> getBookByAuthor(@PathVariable String authorName) {
		logger.info("Entering Get Book By Author Name Function");
		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.OK.value(),GET_OPERATION,bookService.getBookByAuthor(authorName)),HttpStatus.OK);


	}

	@GetMapping("/genre/{genre}")
	public ResponseEntity<HttpResponseStatus> getBookByGenre(@PathVariable String genre) {
		logger.info("Entering Get Book By genre Name Function");
		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.OK.value(),GET_OPERATION,bookService.getBookByGenre(genre)),HttpStatus.OK);

	}


	@GetMapping("/publisher/{publisher}")
	public ResponseEntity<HttpResponseStatus> getBookByPublisher(@PathVariable String publisher) {
		logger.info("Entering Get Book By publisher Name Function");
		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.OK.value(),GET_OPERATION,bookService.getBookByPublisher(publisher)),HttpStatus.OK);

	}

	
	@GetMapping("/isbn/{isbn}")
	public ResponseEntity<HttpResponseStatus> getBookByISBN(@PathVariable Long isbn) {
		logger.info("Entering Get Book By ISBN Function");
		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.OK.value(),GET_OPERATION,bookService.getBookByISBN(isbn)),HttpStatus.OK);

	}

	
	@GetMapping
	public ResponseEntity<HttpResponseStatus> getAllBooks() {
		logger.info("Entering Get All Books Function");
		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.OK.value(),GET_OPERATION,bookService.getAllBooks()),HttpStatus.OK);

	}
	@GetMapping("/searchbooks/{value}")
	public ResponseEntity<HttpResponseStatus> searchBooks( @PathVariable String value) {
		logger.info("Entering Search Books Function");
		return new ResponseEntity<>(new HttpResponseStatus(HttpStatus.OK.value(),GET_OPERATION,bookService.searchBooks(value)),HttpStatus.OK);

	}

}
