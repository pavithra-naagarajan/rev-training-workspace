package com.revature.librarymanagement;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Assert;
import org.junit.Before;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.revature.librarymanagement.model.User;
import com.revature.librarymanagement.response.HttpResponseStatus;
import com.revature.librarymanagement.service.UserService;

@RunWith(SpringRunner.class)
@SpringBootTest
class TestRevatureAppRestDocs {
	private MockMvc mockMvc;
	@Autowired
	private WebApplicationContext context;
	@Autowired
	private UserService userService;

	ObjectMapper om = new ObjectMapper();

	static final List<User> USER_TEST_DATA = Stream.of(
			new User(Long.valueOf(1), "DemoFirstName", "DemoLastName", "Demo123", "Demo@gmail.com", "1234567089",
					"Demo", 21, "Female", "pune"),
			new User(Long.valueOf(2), "DemoFirstName", "DemoLastName", "Demo1234", "Demo123@gmail.com", "9134567089",
					"Demo", 21, "Female", "pune"))
			.collect(Collectors.toList());

			
	@Before
	public void setUp() {
		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
	}
	@Test
	public void getAllUsersTest() throws Exception{
		/*
		 * MvcResult result = mockMvc
		 * .perform(get("/user").content(MediaType.APPLICATION_JSON_VALUE))
		 * .andExpect(status().isOk()).andReturn(); String resultContent =
		 * result.getResponse().getContentAsString(); HttpResponseStatus response =
		 * om.readValue(resultContent, HttpResponseStatus.class);
		 * Assert.assertTrue(response.getStatusCode() == 200);
		 */

		mockMvc.perform(get("/user")
				.contentType("application/json")).andDo(print())
		.andExpect(status().isOk())
		.andExpect(MockMvcResultMatchers.content().json(new ObjectMapper().writeValueAsString(USER_TEST_DATA)));
	}

}
