package com.revature.training.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.revature.training.model.Product;

@Controller
public class ProductController {

	@RequestMapping("productApp")
	public ModelAndView productApp() {
		ModelAndView view = new ModelAndView();
		view.setViewName("productApp");
		return view;
	}

	@RequestMapping("addProductForm")
	public ModelAndView addProductForm() {
		ModelAndView view = new ModelAndView();
		Product product = new Product(123, "laptop", 20, 500);
		view.addObject("product", product);
		view.setViewName("addProductForm");
		return view;
	}

	@RequestMapping("saveProduct")
	public ModelAndView saveProduct(@Valid @ModelAttribute("product") Product product, BindingResult result) {

		ModelAndView view = new ModelAndView();

		if (result.hasErrors()) {
			System.out.println("Has error");
			view.setViewName("addProductForm");
		} else {
			System.out.println("No Error");
			view.setViewName("success");
		}
		System.out.println(product);
		return view;

	}
}
