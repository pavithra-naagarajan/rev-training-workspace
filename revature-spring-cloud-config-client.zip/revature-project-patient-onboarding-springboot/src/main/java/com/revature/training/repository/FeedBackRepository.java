/*
 * package com.revature.training.repository;
 * 
 * import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
 * import org.springframework.data.repository.CrudRepository;
 * 
 * import com.revature.training.model.FeedBack;
 * 
 * @EnableJpaRepositories public interface FeedBackRepository extends
 * CrudRepository<FeedBack, Integer> {
 * 
 * }
 */