package com;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.revature.training.model.Patient;
import com.revature.training.repository.PatientRepository;
import com.revature.training.service.PatientService;



@RunWith(SpringRunner.class)
@SpringBootTest
public class RevatureProjectPatientOnboardingSpringbootApplicationTests {
	
	@Autowired
	private PatientService service;
	
	@MockBean
	private PatientRepository repository;
	long patientId, String address, String gender, String mailId, String mobileNumber, String password,int patientAge,
	String patientName
	@Test
	public void getAllUsersTest() {
		Long demoId=(long) 1;
		when(repository.findAll()).thenReturn(Stream.of(new Patient(demoId,"DemoFirstName","DemoLastName","Demo123","Demo@gmail.com",
				"1234567089","Demo",21,"Female","pune")).collect(Collectors.toList()));
		
		assertEquals(1,service.getAllPatients().size());
	}
	

}
