package com.revature.model;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties("company")
@Component
public class Company {

	
	private String name;
	private String doorNumber;
	private String buildingName;
	private String location;
	private String city;
	private String password;
	
	public Company() {
		
	}

	public Company(String name, String doorNumber, String buildingName, String location, String city, String password) {
		super();
		this.name = name;
		this.doorNumber = doorNumber;
		this.buildingName = buildingName;
		this.location = location;
		this.city = city;
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDoorNumber() {
		return doorNumber;
	}

	public void setDoorNumber(String doorNumber) {
		this.doorNumber = doorNumber;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Company [name=" + name + ", doorNumber=" + doorNumber + ", buildingName=" + buildingName + ", location="
				+ location + ", city=" + city + ", password=" + password + "]";
	}

}
