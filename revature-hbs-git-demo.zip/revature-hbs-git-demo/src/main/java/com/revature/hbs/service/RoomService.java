package com.revature.hbs.service;

public interface RoomService {
	
	

}
