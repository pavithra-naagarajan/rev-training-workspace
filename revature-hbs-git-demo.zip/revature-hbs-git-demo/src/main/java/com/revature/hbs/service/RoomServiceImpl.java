package com.revature.hbs.service;

public class RoomServiceImpl implements RoomService {

}
