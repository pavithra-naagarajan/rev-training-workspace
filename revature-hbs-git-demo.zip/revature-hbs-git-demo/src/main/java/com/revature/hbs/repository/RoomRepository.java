package com.revature.hbs.repository;

import org.springframework.data.repository.CrudRepository;

import com.revature.hbs.model.Room;

public interface RoomRepository extends CrudRepository<Room, Long> {

}
